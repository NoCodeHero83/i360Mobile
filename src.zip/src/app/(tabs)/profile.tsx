import React from "react";
import Profile from "../../components/Profile/Profile";

export default function ProfileScreen() {
  return <Profile />;
}
