// ============================================
// usePropertyForm - Custom hook para el estado del formulario
// Mantiene TODA la API pública del hook anterior. Internamente usa
// un único useReducer en lugar de 50+ useState para reducir renders
// y centralizar la lógica de mutación.
// ============================================

import { useCallback, useEffect, useMemo, useReducer, useRef, useState } from "react";
import { useModal } from "@/context/ModalContext";
import type { LocalModalOptions } from "@/hooks/useLocalModal";
import { supabase } from "../../../lib/supabase";
import { COORDENADAS_ESTADO } from "../../../constants/estadosMexico";
import { DEFAULT_COUNTRY } from "../../../lib/location/registry";
import { pinDentroDeZona } from "../../../lib/geocodingService";
import {
  PROPERTY_TYPES,
  TipoPrincipal,
  esTerreno,
  getCamposVisibles,
} from "../../../constants/propertyData";
import { logger } from "@/utils/logger";
import { formatThousands } from "../../../utils/numberFormatter";

import type {
  AmuebladoType,
  PropertyFormState,
  SiNo,
} from "./types";

const log = logger.scoped("usePropertyForm");

// ============================================
// Tipos auxiliares
// ============================================

/** Permite asignaciones dinámicas sobre un Partial<PropertyFormState> */
type MutablePayload = Record<string, string | number | boolean | null | undefined>;

// ============================================
// Estado inicial
// ============================================

const INITIAL_STATE: PropertyFormState = {
  // Imágenes
  images: [],

  // Información básica
  descripcion: "",
  tipoOperacion: "",
  precioVenta: "",
  precioRenta: "",
  moneda: "MXN",
  tipoPrincipal: "habitacional",
  subtipo: "",
  status: "Publicada",
  originalStatus: "Publicada",

  // Ubicación
  pais: "México",
  ubicacionData: {
    estado: "",
    ciudad: "",
    municipio: "",
    colonia: "",
    pais: DEFAULT_COUNTRY,
  },
  calle: "",
  numeroExterior: "",
  numeroInterior: "",
  codigoPostal: "",
  location: { latitude: 0, longitude: 0 },
  mapCenter: null,

  // Características físicas (sin preseleccionar: el usuario debe elegirlos)
  recamaras: "",
  banosCompletos: "",
  mediosBanos: "",
  estacionamientos: "",
  m2Construccion: "",
  m2Terreno: "",
  anchoTerreno: "",
  largoTerreno: "",
  niveles: "",
  antiguedad: "",
  amueblado: "",
  petFriendly: "",
  costoMantenimiento: "",

  // Amenidades
  amenidadesSeleccionadas: [],

  // Comisión Venta
  comparteComision: "Sí",
  comisionTipo: "porcentaje",
  comisionValor: "",
  comisionCompartidaTipo: "porcentaje",
  comisionCompartidaValor: "50",  // % de mi comisión que comparto (0-100)
  condicionesComision: "",

  // Comisión Renta
  comparteComisionRenta: "Sí",
  comisionTipoRenta: "porcentaje",
  comisionValorRenta: "1",        // default 1 mes
  comisionCompartidaTipoRenta: "porcentaje",
  comisionCompartidaValorRenta: "50",  // % de mi comisión que comparto (0-100)
  condicionesComisionRenta: "",

  // Gravamen (sin preseleccionar)
  tieneGravamen: "",
  institucionGravamen: [],
  montosGravamen: {},

  // Financiamiento (sin preseleccionar)
  aceptaFinanciamiento: "",
  tiposFinanciamientoSeleccionados: [],

  // Propietario
  nombreCompletoPropietario: "",
  emailPropietario: "",
  telefonoPropietario: "",

  // Contrato
  contractData: null,

  // EasyBroker
  sinComision: false,

  // Campos especializados — Agrícola
  tiposAgua: [],
  concesionAgua: false,
  usoTerreno: [],
  tipoRiego: [],
  infraElectricidad: false,
  infraCaminoAcceso: false,
  infraCercado: false,
  accesoCarretera: false,
  accesoCamiones: false,

  // Campos especializados — Comercial
  tipoUbicacionComercial: '',
  frenteMetros: '',
  nivelPiso: '',
  sobreAvenidaPrincipal: false,
  enEsquina: false,
  altaVisibilidad: false,
  altoFlujoVehicular: false,

  // Campos especializados — Industrial
  ubicacionIndustrial: '',
  alturaLibreM: '',
  tipoEnergiaKva: [],
  areaOficinas: '',
  patioManiobras: '',

  // Errores
  errors: {},
};

// ============================================
// Acciones tipadas
// ============================================

type SetFieldAction = {
  [K in keyof PropertyFormState]: {
    type: "SET_FIELD";
    field: K;
    value: PropertyFormState[K];
  };
}[keyof PropertyFormState];

type UpdateFieldAction = {
  [K in keyof PropertyFormState]: {
    type: "UPDATE_FIELD";
    field: K;
    updater: (prev: PropertyFormState[K]) => PropertyFormState[K];
  };
}[keyof PropertyFormState];

type PropertyFormAction =
  | SetFieldAction
  | UpdateFieldAction
  | { type: "LOAD"; payload: Partial<PropertyFormState> }
  | { type: "CLEAR_ERROR"; key: string }
  | { type: "TOGGLE_AMENIDAD"; amenidad: string }
  | { type: "TOGGLE_FINANCIAMIENTO"; tipo: string };

/** Mensaje único para el caso "PIN fuera de la zona escrita" (validate + feedback en vivo). */
const PIN_FUERA_DE_ZONA_MSG =
  "El pin está fuera de la zona seleccionada. Arrástralo a la ubicación real o ajusta la ubicación escrita.";

function reducer(
  state: PropertyFormState,
  action: PropertyFormAction,
): PropertyFormState {
  switch (action.type) {
    case "SET_FIELD":
      return { ...state, [action.field]: action.value };
    case "UPDATE_FIELD": {
      const updater = action.updater as (v: unknown) => unknown;
      return {
        ...state,
        [action.field]: updater(state[action.field]),
      };
    }
    case "LOAD":
      return { ...state, ...action.payload };
    case "CLEAR_ERROR": {
      if (!state.errors[action.key]) return state;
      const { [action.key]: _removed, ...rest } = state.errors;
      return { ...state, errors: rest };
    }
    case "TOGGLE_AMENIDAD": {
      const list = state.amenidadesSeleccionadas;
      return {
        ...state,
        amenidadesSeleccionadas: list.includes(action.amenidad)
          ? list.filter((a) => a !== action.amenidad)
          : [...list, action.amenidad],
      };
    }
    case "TOGGLE_FINANCIAMIENTO": {
      const list = state.tiposFinanciamientoSeleccionados;
      return {
        ...state,
        tiposFinanciamientoSeleccionados: list.includes(action.tipo)
          ? list.filter((t) => t !== action.tipo)
          : [...list, action.tipo],
      };
    }
    default:
      return state;
  }
}

// ============================================
// Helpers de tipado para setters
// ============================================

type Updater<T> = T | ((prev: T) => T);

// ============================================
// Hook
// ============================================

/**
 * Huella del formulario para detectar cambios sin guardar. Se ignoran:
 * - `errors`: estado derivado de la validación, no datos del usuario.
 * - `mapCenter`: valor derivado de la ubicación; un efecto lo re-calcula tras
 *   cargar la propiedad en edición, lo que marcaba el formulario como "sucio"
 *   sin que el usuario tocara nada (rompía el botón Atrás al editar).
 */
function serializeForm(state: PropertyFormState): string {
  const { errors: _errors, mapCenter: _mapCenter, ...fields } = state;
  return JSON.stringify(fields);
}

export function usePropertyForm(
  propertyId?: string,
  onBack?: (shouldRefresh?: boolean) => void,
  // Ver nota en usePublishProperty: en edición se inyecta un showModal LOCAL
  // para que el aviso se vea sobre el <Modal> nativo en iOS.
  showModalOverride?: (options: LocalModalOptions) => void,
) {
  const [state, dispatch] = useReducer(reducer, INITIAL_STATE);
  const { showModal: globalShowModal } = useModal();
  const showModal = showModalOverride ?? globalShowModal;

  // Loading state — es estado de transacción (no de formulario), se queda como useState
  const [isLoadingProperty, setIsLoadingProperty] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Detección de cambios sin guardar, para poder confirmar antes de descartar.
  // Se lee vía ref para que `isDirty` no cambie de identidad en cada tecleo.
  const stateRef = useRef(state);
  stateRef.current = state;
  const baselineRef = useRef(serializeForm(INITIAL_STATE));

  // En edición la línea base es la propiedad ya cargada, no el estado vacío:
  // `dispatch({type:"LOAD"})` y `setIsLoadingProperty(false)` se agrupan en el
  // mismo render, así que aquí `stateRef` ya contiene los datos cargados.
  useEffect(() => {
    if (propertyId && !isLoadingProperty) {
      baselineRef.current = serializeForm(stateRef.current);
    }
  }, [propertyId, isLoadingProperty]);

  const isDirty = useCallback(
    () => serializeForm(stateRef.current) !== baselineRef.current,
    [],
  );

  // ============================================
  // Setter factory — una por campo, memoizado con useCallback
  // ============================================

  const makeSetter = <K extends keyof PropertyFormState>(field: K) =>
    useCallback(
      (value: Updater<PropertyFormState[K]>) => {
        if (typeof value === "function") {
          dispatch({
            type: "UPDATE_FIELD",
            field,
            updater: value as (p: PropertyFormState[K]) => PropertyFormState[K],
          } as unknown as PropertyFormAction);
        } else {
          dispatch({
            type: "SET_FIELD",
            field,
            value,
          } as unknown as PropertyFormAction);
        }
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [],
    );

  const setImages = makeSetter("images");
  const setDescripcion = makeSetter("descripcion");
  const setTipoOperacion = makeSetter("tipoOperacion");
  const setPrecioVenta = makeSetter("precioVenta");
  const setPrecioRenta = makeSetter("precioRenta");
  const setMoneda = makeSetter("moneda");
  const setTipoPrincipal = makeSetter("tipoPrincipal");
  const setSubtipo = makeSetter("subtipo");
  const setStatus = makeSetter("status");
  const setUbicacionData = makeSetter("ubicacionData");
  const setCalle = makeSetter("calle");
  const setNumeroExterior = makeSetter("numeroExterior");
  const setNumeroInterior = makeSetter("numeroInterior");
  const setCodigoPostal = makeSetter("codigoPostal");
  const setLocation = makeSetter("location");
  const setMapCenter = makeSetter("mapCenter");
  const setRecamaras = makeSetter("recamaras");
  const setBanosCompletos = makeSetter("banosCompletos");
  const setMediosBanos = makeSetter("mediosBanos");
  const setEstacionamientos = makeSetter("estacionamientos");
  const setM2Construccion = makeSetter("m2Construccion");
  const setM2Terreno = makeSetter("m2Terreno");
  const setAnchoTerreno = makeSetter("anchoTerreno");
  const setLargoTerreno = makeSetter("largoTerreno");
  const setNiveles = makeSetter("niveles");
  const setCostoMantenimiento = makeSetter("costoMantenimiento");
  const setAntiguedad = makeSetter("antiguedad");
  const setAmueblado = makeSetter("amueblado");
  const setPetFriendly = makeSetter("petFriendly");
  const setComparteComision = makeSetter("comparteComision");
  const setComisionTipo = makeSetter("comisionTipo");
  const setComisionValor = makeSetter("comisionValor");
  const setComisionCompartidaTipo = makeSetter("comisionCompartidaTipo");
  const setComisionCompartidaValor = makeSetter("comisionCompartidaValor");
  const setCondicionesComision = makeSetter("condicionesComision");
  const setComparteComisionRenta = makeSetter("comparteComisionRenta");
  const setComisionTipoRenta = makeSetter("comisionTipoRenta");
  const setComisionValorRenta = makeSetter("comisionValorRenta");
  const setComisionCompartidaTipoRenta = makeSetter("comisionCompartidaTipoRenta");
  const setComisionCompartidaValorRenta = makeSetter("comisionCompartidaValorRenta");
  const setCondicionesComisionRenta = makeSetter("condicionesComisionRenta");
  const setTieneGravamen = makeSetter("tieneGravamen");
  const setInstitucionGravamen = makeSetter("institucionGravamen");
  const setMontosGravamen = makeSetter("montosGravamen");
  const setAceptaFinanciamiento = makeSetter("aceptaFinanciamiento");
  const setNombreCompletoPropietario = makeSetter("nombreCompletoPropietario");
  const setEmailPropietario = makeSetter("emailPropietario");
  const setTelefonoPropietario = makeSetter("telefonoPropietario");
  const setContractData = makeSetter("contractData");
  const setErrors = makeSetter("errors");

  // Setters especializados — Agrícola
  const setConcesionAgua = makeSetter("concesionAgua");
  const setInfraElectricidad = makeSetter("infraElectricidad");
  const setInfraCaminoAcceso = makeSetter("infraCaminoAcceso");
  const setInfraCercado = makeSetter("infraCercado");
  const setAccesoCarretera = makeSetter("accesoCarretera");
  const setAccesoCamiones = makeSetter("accesoCamiones");

  // Setters especializados — Comercial
  const setTipoUbicacionComercial = makeSetter("tipoUbicacionComercial");
  const setFrenteMetros = makeSetter("frenteMetros");
  const setNivelPiso = makeSetter("nivelPiso");
  const setSobreAvenidaPrincipal = makeSetter("sobreAvenidaPrincipal");
  const setEnEsquina = makeSetter("enEsquina");
  const setAltaVisibilidad = makeSetter("altaVisibilidad");
  const setAltoFlujoVehicular = makeSetter("altoFlujoVehicular");

  // Setters especializados — Industrial
  const setUbicacionIndustrial = makeSetter("ubicacionIndustrial");
  const setAlturaLibreM = makeSetter("alturaLibreM");
  const setAreaOficinas = makeSetter("areaOficinas");
  const setPatioManiobras = makeSetter("patioManiobras");

  const toggleTipoAgua = useCallback((tipo: string) => {
    dispatch({
      type: "UPDATE_FIELD",
      field: "tiposAgua",
      updater: (prev: string[]) =>
        prev.includes(tipo) ? prev.filter((t) => t !== tipo) : [...prev, tipo],
    } as unknown as PropertyFormAction);
  }, []);

  const toggleUsoTerreno = useCallback((tipo: string) => {
    dispatch({
      type: "UPDATE_FIELD",
      field: "usoTerreno",
      updater: (prev: string[]) =>
        prev.includes(tipo) ? prev.filter((t) => t !== tipo) : [...prev, tipo],
    } as unknown as PropertyFormAction);
  }, []);

  const toggleTipoRiego = useCallback((tipo: string) => {
    dispatch({
      type: "UPDATE_FIELD",
      field: "tipoRiego",
      updater: (prev: string[]) =>
        prev.includes(tipo) ? prev.filter((t) => t !== tipo) : [...prev, tipo],
    } as unknown as PropertyFormAction);
  }, []);

  const toggleTipoEnergiaKva = useCallback((tipo: string) => {
    dispatch({
      type: "UPDATE_FIELD",
      field: "tipoEnergiaKva",
      updater: (prev: string[]) =>
        prev.includes(tipo) ? prev.filter((t) => t !== tipo) : [...prev, tipo],
    } as unknown as PropertyFormAction);
  }, []);

  // ============================================
  // Helpers derivados
  // ============================================

  const clearError = useCallback((key: string) => {
    dispatch({ type: "CLEAR_ERROR", key });
  }, []);

  const toggleAmenidad = useCallback((amenidad: string) => {
    dispatch({ type: "TOGGLE_AMENIDAD", amenidad });
  }, []);

  const toggleFinanciamiento = useCallback((tipo: string) => {
    dispatch({ type: "TOGGLE_FINANCIAMIENTO", tipo });
  }, []);

  const handleCurrencyChange = useCallback(
    (text: string, setter: (val: string) => void) => {
      const rawValue = text.replace(/,/g, "");
      if (/^\d*\.?\d*$/.test(rawValue)) {
        const parts = rawValue.split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        setter(parts.join("."));
      }
    },
    [],
  );

  // ============================================
  // COMPUTED
  // ============================================

  const camposVisibles = useMemo(
    () => getCamposVisibles(state.subtipo, state.tipoPrincipal as TipoPrincipal),
    [state.subtipo, state.tipoPrincipal],
  );

  const PROPERTY_STATUS = [
    "Publicada",
    "Suspendida",
    "Rentada",
    "Reservada",
    "Vendida",
  ] as const;

  const filteredStatusOptions = useMemo(() => {
    return PROPERTY_STATUS.filter((option) => {
      if (state.sinComision && option === "Publicada") return false;
      if (state.tipoOperacion === "venta") return option !== "Rentada";
      if (state.tipoOperacion === "renta") return option !== "Vendida";
      return true;
    });
  }, [state.tipoOperacion, state.sinComision]);

  const isColoniaMode = useMemo(() => {
    return (
      !!state.ubicacionData.colonia &&
      !!state.ubicacionData.latitud &&
      !!state.ubicacionData.longitud
    );
  }, [
    state.ubicacionData.colonia,
    state.ubicacionData.latitud,
    state.ubicacionData.longitud,
  ]);

  // ============================================
  // EFFECTS: auto-limpieza de errores cuando el campo se llena
  // ============================================

  useEffect(() => {
    if (state.ubicacionData.estado) clearError("estado");
    if (state.ubicacionData.municipio) clearError("municipio");
  }, [state.ubicacionData, clearError]);

  useEffect(() => {
    if (state.images.length > 0) clearError("images");
  }, [state.images, clearError]);

  useEffect(() => {
    if (state.descripcion.trim()) clearError("descripcion");
  }, [state.descripcion, clearError]);

  useEffect(() => {
    if (state.subtipo) clearError("subtipo");
  }, [state.subtipo, clearError]);

  useEffect(() => {
    if (state.precioVenta.trim()) clearError("precioVenta");
  }, [state.precioVenta, clearError]);

  useEffect(() => {
    if (state.precioRenta.trim()) clearError("precioRenta");
  }, [state.precioRenta, clearError]);

  // PIN del mapa: limpia el error si entra en la zona escrita; lo marca en vivo
  // si queda fuera (sin esperar al submit). Si no hay PIN aún, el caso lo cubre
  // validate(). Sin bounds, pinDentroDeZona devuelve true (no se valida).
  useEffect(() => {
    const { latitude, longitude } = state.location;
    if (latitude === 0 && longitude === 0) return;
    const dentro = pinDentroDeZona(latitude, longitude, state.ubicacionData.bounds);
    dispatch({
      type: "UPDATE_FIELD",
      field: "errors",
      updater: (prev) => {
        if (dentro) {
          if (!prev.location) return prev;
          const { location: _omit, ...rest } = prev;
          return rest;
        }
        if (prev.location === PIN_FUERA_DE_ZONA_MSG) return prev;
        return { ...prev, location: PIN_FUERA_DE_ZONA_MSG };
      },
    });
  }, [state.location, state.ubicacionData.bounds]);

  // Campos sin preselección: limpiar su error en cuanto el usuario los completa.
  useEffect(() => {
    if (state.tipoOperacion) clearError("tipoOperacion");
    if (state.recamaras) clearError("recamaras");
    if (state.banosCompletos) clearError("banos");
    if (state.mediosBanos) clearError("mediosBanos");
    if (state.estacionamientos) clearError("estacionamientos");
    if (state.niveles) clearError("niveles");
    if (state.amueblado) clearError("amueblado");
    if (state.petFriendly) clearError("petFriendly");
    if (state.tieneGravamen) clearError("gravamen");
    if (state.aceptaFinanciamiento) clearError("financiamiento");
  }, [
    state.tipoOperacion,
    state.recamaras,
    state.banosCompletos,
    state.mediosBanos,
    state.estacionamientos,
    state.niveles,
    state.amueblado,
    state.petFriendly,
    state.tieneGravamen,
    state.aceptaFinanciamiento,
    clearError,
  ]);

  // Comisión: limpiar el error en cuanto deja de compartir o define un valor > 0.
  useEffect(() => {
    if (state.comparteComision !== "Sí" || (parseFloat(state.comisionValor) || 0) > 0) {
      clearError("comision");
    }
  }, [state.comparteComision, state.comisionValor, clearError]);

  useEffect(() => {
    const share =
      state.tipoOperacion === "ambas"
        ? state.comparteComisionRenta
        : state.comparteComision;
    const raw =
      state.tipoOperacion === "ambas"
        ? state.comisionValorRenta
        : state.comisionValor;
    if (share !== "Sí" || (parseFloat(raw) || 0) > 0) {
      clearError("comisionRenta");
    }
  }, [
    state.tipoOperacion,
    state.comparteComisionRenta,
    state.comparteComision,
    state.comisionValorRenta,
    state.comisionValor,
    clearError,
  ]);

  // ============================================
  // MAP CENTER BASED ON STATE OR GEO COORDS
  // ============================================

  // Clave (lat,lng) de la última colonia aplicada al pin, para colocar el pin
  // solo cuando la colonia CAMBIA (no en cada cambio de ubicacionData).
  const lastColoniaKeyRef = useRef<string | null>(null);

  useEffect(() => {
    const { latitud, longitud, estado, colonia } = state.ubicacionData;
    if (latitud && longitud) {
      dispatch({
        type: "SET_FIELD",
        field: "mapCenter",
        value: { lat: latitud, lng: longitud },
      });

      // Al elegir una colonia, colocar el pin en su centro como punto de
      // partida (el asesor lo arrastra al lugar exacto). Solo cuando la
      // colonia cambia. En edición NO se pisa un pin ya guardado.
      if (colonia) {
        const key = `${latitud},${longitud}`;
        if (key !== lastColoniaKeyRef.current) {
          lastColoniaKeyRef.current = key;
          const hasPin =
            state.location.latitude !== 0 || state.location.longitude !== 0;
          if (!propertyId || !hasPin) {
            dispatch({
              type: "SET_FIELD",
              field: "location",
              value: { latitude: latitud, longitude: longitud },
            });
          }
        }
      }
    } else if (estado && COORDENADAS_ESTADO[estado]) {
      dispatch({
        type: "SET_FIELD",
        field: "mapCenter",
        value: COORDENADAS_ESTADO[estado],
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.ubicacionData]);

  // ============================================
  // LOAD DATA FOR EDITING
  // ============================================

  const onBackRef = useRef(onBack);
  useEffect(() => {
    onBackRef.current = onBack;
  }, [onBack]);

  const fetchPropertyDetails = useCallback(async () => {
    if (!propertyId) return;
    try {
      setIsLoadingProperty(true);
      setLoadError(null);

      const timeoutPromise = new Promise<never>((_, reject) =>
        setTimeout(
          () =>
            reject(
              new Error("Tiempo de espera agotado al cargar la propiedad"),
            ),
          30000,
        ),
      );

      const fetchPromise = supabase
        .from("propiedades")
        .select(
          `
          *,
          operaciones_propiedad (*),
          propiedad_amenidades (
            catalogo_amenidades (nombre)
          ),
          propiedad_financiamientos (
            catalogo_tipos_financiamiento (nombre)
          ),
          propiedad_gravamenes (
            monto,
            catalogo_instituciones_financieras (nombre)
          )
        `,
        )
        .eq("id", propertyId)
        .single();

      const { data, error } = await Promise.race([
        fetchPromise,
        timeoutPromise,
      ]);

      if (error) throw error;
      if (data) loadPropertyData(data);
    } catch (e: unknown) {
      log.error("Error fetching property:", e);
      const errorMsg =
        e instanceof Error ? e.message : "No se pudo cargar la información de la propiedad";
      setLoadError(errorMsg);
      showModal({
        title: "Error al cargar",
        message: errorMsg,
        confirmText: "Reintentar",
        cancelText: "Volver",
        onConfirm: () => fetchPropertyDetails(),
        onCancel: () => onBackRef.current?.(),
      });
    } finally {
      setIsLoadingProperty(false);
    }
  }, [propertyId]);

  useEffect(() => {
    if (propertyId) {
      fetchPropertyDetails();
    }
  }, [propertyId, fetchPropertyDetails]);

  const loadPropertyData = (data: any) => {
    try {
      const payload: Partial<PropertyFormState> = {};

      // 1. Imágenes
      if (data.fotos && Array.isArray(data.fotos)) {
        payload.images = data.fotos;
      }

      // 2. Info Básica
      payload.descripcion = data.descripcion || "";
      payload.status = data.status || "Publicada";
      payload.sinComision = data.sin_comision ?? false;
      payload.originalStatus = data.status || "Publicada";

      const rawTipo = (data.tipo || "habitacional").toLowerCase();
      const isValidTipo = Object.keys(PROPERTY_TYPES).includes(rawTipo);
      payload.tipoPrincipal = isValidTipo
        ? (rawTipo as TipoPrincipal)
        : "habitacional";
      payload.subtipo = data.subtipo || "";

      // 3. Ubicación
      payload.ubicacionData = {
        estado: data.estado || "",
        ciudad: data.ciudad || "",
        municipio: data.municipio || data.ciudad || "",
        colonia: data.colonia || "",
      };
      payload.calle = data.calle || "";
      payload.numeroExterior = data.numero_exterior || "";
      payload.numeroInterior = data.numero_interior || "";
      payload.codigoPostal = "";
      payload.location = {
        latitude: data.latitud || 0,
        longitude: data.longitud || 0,
      };

      // 4. Características Físicas
      payload.recamaras = data.habitaciones?.toString() || "0";
      payload.banosCompletos = data.banos?.toString() || "0";
      payload.mediosBanos = data.medios_banos != null ? data.medios_banos.toString() : "";
      payload.estacionamientos = data.estacionamientos?.toString() || "0";
      payload.m2Construccion = data.metros_cuadrados_construccion
        ? formatThousands(data.metros_cuadrados_construccion.toString())
        : "";
      payload.m2Terreno = data.metros_cuadrados_terreno
        ? formatThousands(data.metros_cuadrados_terreno.toString())
        : "";
      payload.anchoTerreno = data.ancho_terreno != null
        ? formatThousands(data.ancho_terreno.toString())
        : '';
      payload.largoTerreno = data.largo_terreno != null
        ? formatThousands(data.largo_terreno.toString())
        : '';
      payload.costoMantenimiento = data.costo_mantenimiento != null
        ? formatThousands(data.costo_mantenimiento.toString())
        : '';
      payload.niveles = data.pisos?.toString() || "1";
      payload.antiguedad = data.antiguedad || "";
      payload.amueblado = (data.amueblado || "No") as AmuebladoType;
      payload.petFriendly = (data.pet_friendly || "No") as SiNo;
      payload.nombreCompletoPropietario = data.nombre_propietario || "";
      payload.emailPropietario = data.email_propietario || "";
      payload.telefonoPropietario = data.telefono_propietario || "";

      // 5. Operaciones
      const ops = data.operaciones_propiedad || [];
      const ventaOp = ops.find((o: any) => o.tipo_operacion === "venta");
      const rentaOp = ops.find((o: any) => o.tipo_operacion === "renta");

      if (ventaOp && rentaOp) {
        payload.tipoOperacion = "ambas";
      } else if (ventaOp) {
        payload.tipoOperacion = "venta";
      } else if (rentaOp) {
        payload.tipoOperacion = "renta";
      }

      if (data.latitud && data.longitud) {
        payload.mapCenter = { lat: data.latitud, lng: data.longitud };
      }

      // Configurar campos de VENTA
      if (ventaOp) {
        payload.precioVenta = ventaOp.precio != null
          ? formatThousands(ventaOp.precio.toString())
          : "";
        payload.moneda = ventaOp.moneda || "MXN";
        payload.comparteComision = ventaOp.comparte_comision ? "Sí" : "No";

        // Porcentaje propio (siempre, no solo cuando comparte)
        if (ventaOp.comision_porcentaje) {
          payload.comisionValor = ventaOp.comision_porcentaje.toString();
        }

        if (ventaOp.comparte_comision) {
          if (ventaOp.porcentaje_comision_compartida) {
            const myPct = ventaOp.comision_porcentaje || 0;
            const sharePct = myPct > 0
              ? Math.round(ventaOp.porcentaje_comision_compartida / myPct * 100)
              : 50;
            payload.comisionCompartidaValor = String(Math.min(100, Math.max(0, sharePct)));
          }
          payload.condicionesComision =
            ventaOp.condiciones_comision_compartida || "";
        }
      }

      // Configurar campos de RENTA
      if (rentaOp) {
        payload.precioRenta = rentaOp.precio != null
          ? formatThousands(rentaOp.precio.toString())
          : "";
        if (!ventaOp) payload.moneda = rentaOp.moneda || "MXN";

        const isAmbas = !!ventaOp;
        const valorPropKey = isAmbas ? "comisionValorRenta" : "comisionValor";
        const compartePropKey = isAmbas ? "comparteComisionRenta" : "comparteComision";
        const compartidaValorPropKey = isAmbas
          ? "comisionCompartidaValorRenta"
          : "comisionCompartidaValor";
        const condicionesPropKey = isAmbas
          ? "condicionesComisionRenta"
          : "condicionesComision";

        const mutablePayload = payload as unknown as MutablePayload;

        // Comisión en meses (nuevo sistema)
        if (rentaOp.comision_meses) {
          mutablePayload[valorPropKey] = rentaOp.comision_meses.toString();
        }

        mutablePayload[compartePropKey] = rentaOp.comparte_comision ? "Sí" : "No";

        if (rentaOp.comparte_comision) {
          // porcentaje_comision_compartida almacena los meses compartidos para renta
          if (rentaOp.porcentaje_comision_compartida) {
            const myMeses = rentaOp.comision_meses || 0;
            const sharePct = myMeses > 0
              ? Math.round(rentaOp.porcentaje_comision_compartida / myMeses * 100)
              : 50;
            mutablePayload[compartidaValorPropKey] = String(Math.min(100, Math.max(0, sharePct)));
          }
          mutablePayload[condicionesPropKey] =
            rentaOp.condiciones_comision_compartida || "";
        }
      }

      // 6. Amenidades
      if (data.propiedad_amenidades) {
        payload.amenidadesSeleccionadas = data.propiedad_amenidades
          .map((pa: any) => pa.catalogo_amenidades?.nombre)
          .filter(Boolean);
      }

      // 7. Financiamiento
      if (
        data.propiedad_financiamientos &&
        data.propiedad_financiamientos.length > 0
      ) {
        payload.aceptaFinanciamiento = "Sí";
        payload.tiposFinanciamientoSeleccionados =
          data.propiedad_financiamientos
            .map((pf: any) => pf.catalogo_tipos_financiamiento?.nombre)
            .filter(Boolean);
      } else {
        payload.aceptaFinanciamiento = "No";
      }

      // 8. Gravamen
      if (data.propiedad_gravamenes && data.propiedad_gravamenes.length > 0) {
        payload.tieneGravamen = "Sí";
        payload.institucionGravamen = data.propiedad_gravamenes.map(
          (grav: any) => grav.catalogo_instituciones_financieras?.nombre || ""
        );
        const montos: Record<string, string> = {};
        data.propiedad_gravamenes.forEach((grav: any) => {
          const nombre = grav.catalogo_instituciones_financieras?.nombre;
          if (nombre) {
            montos[nombre] =
              grav.monto != null ? formatThousands(grav.monto.toString()) : "";
          }
        });
        payload.montosGravamen = montos;
      } else {
        payload.tieneGravamen = "No";
        payload.institucionGravamen = [];
      }

      // 9. Campos especializados
      payload.tiposAgua = data.tipo_agua ?? [];
      payload.concesionAgua = data.concesion_agua ?? false;
      payload.usoTerreno = Array.isArray(data.uso_terreno)
        ? data.uso_terreno
        : (data.uso_terreno ? [data.uso_terreno] : []);
      payload.tipoRiego = Array.isArray(data.tipo_riego)
        ? data.tipo_riego
        : (data.tipo_riego ? [data.tipo_riego] : []);
      payload.infraElectricidad = data.infra_electricidad ?? false;
      payload.infraCaminoAcceso = data.infra_camino_acceso ?? false;
      payload.infraCercado = data.infra_cercado ?? false;
      payload.accesoCarretera = data.acceso_carretera ?? false;
      payload.accesoCamiones = data.acceso_camiones ?? false;
      payload.tipoUbicacionComercial = data.tipo_ubicacion_comercial ?? '';
      payload.frenteMetros = data.frente_metros?.toString() ?? '';
      payload.nivelPiso = data.nivel_piso?.toString() ?? '';
      payload.sobreAvenidaPrincipal = data.sobre_avenida_principal ?? false;
      payload.enEsquina = data.en_esquina ?? false;
      payload.altaVisibilidad = data.alta_visibilidad ?? false;
      payload.altoFlujoVehicular = data.alto_flujo_vehicular ?? false;
      payload.ubicacionIndustrial = data.ubicacion_industrial ?? '';
      payload.alturaLibreM = data.altura_libre_m ?? '';
      const ENERGIA_LEGACY: Record<string, string> = {
        'Trifásica 25 kVA': 'Monofásica: hasta 25 kVA',
        'Trifásica 45 kVA': 'Trifásica: 25 a 45 kVA',
        'Trifásica 150 kVA': 'Industrial: 45 a 150 kVA',
        'Más de 150 kVA': 'Alta capacidad: más de 150 kVA',
      };
      payload.tipoEnergiaKva = (data.tipo_energia_kva ?? []).map(
        (v: string) => ENERGIA_LEGACY[v] ?? v
      );
      payload.areaOficinas = data.area_oficinas_m2?.toString() ?? '';
      payload.patioManiobras = data.patio_maniobras_m2?.toString() ?? '';

      dispatch({ type: "LOAD", payload });
    } catch (e: unknown) {
      log.error("Error loading property data:", e);
      setLoadError("Error al procesar los datos de la propiedad");
    }
  };

  // ============================================
  // VALIDACIÓN
  // ============================================

  // Guarda los errores recién calculados de forma síncrona, para que el flujo de
  // publicación pueda leerlos (y hacer scroll al primero) sin esperar al re-render.
  const lastErrorsRef = useRef<Record<string, string>>({});
  const getValidationErrors = useCallback(
    () => lastErrorsRef.current,
    [],
  );

  const validate = useCallback((): boolean => {
    const newErrors: Record<string, string> = {};
    // Campos visibles según tipo/subtipo (para exigir solo lo que se muestra).
    const cv = getCamposVisibles(state.subtipo, state.tipoPrincipal as TipoPrincipal);

    // Los chequeos siguen el MISMO orden visual del formulario (de arriba hacia
    // abajo), para que el resaltado y el scroll-al-error sean coherentes.

    // 1) Imágenes
    if (state.images.length === 0) {
      newErrors.images = "Debes agregar al menos 1 imagen";
    }

    // 2) Información básica: subtipo → operación → precio → descripción
    if (!state.subtipo) {
      newErrors.subtipo = "Debes seleccionar un subtipo de propiedad";
    }
    if (!state.tipoOperacion) {
      newErrors.tipoOperacion = "Selecciona el tipo de operación";
    }
    if (state.tipoOperacion === "venta" && !state.precioVenta.trim()) {
      newErrors.precioVenta = "El precio de venta es requerido";
    }
    if (state.tipoOperacion === "renta" && !state.precioRenta.trim()) {
      newErrors.precioRenta = "El precio de renta es requerido";
    }
    if (state.tipoOperacion === "ambas") {
      if (!state.precioVenta.trim())
        newErrors.precioVenta = "El precio de venta es requerido";
      if (!state.precioRenta.trim())
        newErrors.precioRenta = "El precio de renta es requerido";
    }
    if (!state.descripcion.trim()) {
      newErrors.descripcion = "La descripción es requerida";
    }

    // 3) Ubicación. Solo se exige el estado: el municipio puede quedar vacío
    // cuando el usuario elige una ubicación a nivel estado en Google Places (que
    // deja municipio en blanco a propósito); la ubicación precisa se captura
    // aparte con el pin del mapa.
    if (!state.ubicacionData.estado)
      newErrors.estado = "El estado es requerido";

    // 4) Características físicas (en el orden en que aparecen en pantalla),
    // obligatorias solo cuando el campo es visible para el tipo/subtipo. Los
    // selectores inician vacíos (sin preseleccionar).
    if (cv.recamaras && !state.recamaras)
      newErrors.recamaras = "Indica el número de recámaras";
    if (cv.banos && !state.banosCompletos)
      newErrors.banos = "Indica el número de baños";
    if (cv.mediosBanos && !state.mediosBanos)
      newErrors.mediosBanos = "Indica el número de medios baños";
    if (cv.estacionamientos && !state.estacionamientos)
      newErrors.estacionamientos = "Indica el número de estacionamientos";
    if (cv.niveles && !state.niveles)
      newErrors.niveles = "Indica el número de niveles";
    if (esTerreno(state.subtipo)) {
      if (!state.m2Terreno.trim()) {
        newErrors.m2Terreno =
          "Los m² de terreno son obligatorios para terrenos";
      }
    } else {
      if (!state.m2Construccion.trim() && !state.m2Terreno.trim()) {
        newErrors.m2 =
          "Debes especificar al menos m² de construcción o terreno";
      }
    }
    if (cv.amueblado && !state.amueblado)
      newErrors.amueblado = "Indica si está amueblado";
    if (
      (state.tipoOperacion === "renta" || state.tipoOperacion === "ambas") &&
      cv.petFriendly &&
      !state.petFriendly
    )
      newErrors.petFriendly = "Indica si se permiten mascotas";

    // 5) Comisión: no tiene sentido compartir 0% (venta) ni 0 meses (renta).
    const comisionVentaNum = parseFloat(state.comisionValor) || 0;
    const comisionRentaNum =
      parseFloat(
        state.tipoOperacion === "ambas"
          ? state.comisionValorRenta
          : state.comisionValor,
      ) || 0;
    if (
      (state.tipoOperacion === "venta" || state.tipoOperacion === "ambas") &&
      state.comparteComision === "Sí" &&
      comisionVentaNum === 0
    ) {
      newErrors.comision =
        "No puedes compartir una comisión de 0%. Define un porcentaje mayor antes de publicar.";
    }
    if (
      (state.tipoOperacion === "renta" || state.tipoOperacion === "ambas") &&
      (state.tipoOperacion === "ambas"
        ? state.comparteComisionRenta
        : state.comparteComision) === "Sí" &&
      comisionRentaNum === 0
    ) {
      newErrors.comisionRenta =
        "No puedes compartir una comisión de 0 meses. Define un valor mayor antes de publicar.";
    }

    // 6) Gravamen y Financiamiento (siempre visibles)
    if (!state.tieneGravamen)
      newErrors.gravamen = "Indica si la propiedad tiene gravamen";
    if (!state.aceptaFinanciamiento)
      newErrors.financiamiento = "Indica si aceptas financiamiento";

    // 7) Ubicación exacta en el mapa (sección final)
    if (state.location.latitude === 0 && state.location.longitude === 0) {
      newErrors.location =
        "Marca la ubicación exacta en el mapa. Si no lo haces, tu propiedad no podrá ser encontrada por asesores ni clientes.";
    } else if (
      // El PIN debe caer dentro de la zona escrita (cuando Google nos dio su área).
      // Evita que el texto diga "Aguascalientes" y el PIN quede en otro estado:
      // el matching usa solo el PIN, así que un PIN inconsistente "esconde" la
      // propiedad de las búsquedas correctas. Si no hay bounds, no se valida.
      !pinDentroDeZona(
        state.location.latitude,
        state.location.longitude,
        state.ubicacionData.bounds,
      )
    ) {
      newErrors.location = PIN_FUERA_DE_ZONA_MSG;
    }

    lastErrorsRef.current = newErrors;
    dispatch({ type: "SET_FIELD", field: "errors", value: newErrors });
    return Object.keys(newErrors).length === 0;
  }, [state]);

  // ============================================
  // Return — API pública idéntica al hook anterior
  // ============================================

  return {
    // Loading
    isLoadingProperty,
    loadError,
    retryLoad: fetchPropertyDetails,

    // Status
    status: state.status,
    setStatus,
    originalStatus: state.originalStatus,
    filteredStatusOptions,

    // Contract
    contractData: state.contractData,
    setContractData,

    // Images
    images: state.images,
    setImages,

    // Información Básica
    descripcion: state.descripcion,
    setDescripcion,
    tipoOperacion: state.tipoOperacion,
    setTipoOperacion,
    precioVenta: state.precioVenta,
    setPrecioVenta,
    precioRenta: state.precioRenta,
    setPrecioRenta,
    moneda: state.moneda,
    setMoneda,
    tipoPrincipal: state.tipoPrincipal as TipoPrincipal,
    setTipoPrincipal,
    subtipo: state.subtipo,
    setSubtipo,

    // Ubicación
    pais: state.pais,
    ubicacionData: state.ubicacionData,
    setUbicacionData,
    calle: state.calle,
    setCalle,
    numeroExterior: state.numeroExterior,
    setNumeroExterior,
    numeroInterior: state.numeroInterior,
    setNumeroInterior,
    codigoPostal: state.codigoPostal,
    setCodigoPostal,
    location: state.location,
    setLocation,
    mapCenter: state.mapCenter,
    setMapCenter,
    isColoniaMode,

    // Características Físicas
    recamaras: state.recamaras,
    setRecamaras,
    banosCompletos: state.banosCompletos,
    setBanosCompletos,
    mediosBanos: state.mediosBanos,
    setMediosBanos,
    estacionamientos: state.estacionamientos,
    setEstacionamientos,
    m2Construccion: state.m2Construccion,
    setM2Construccion,
    m2Terreno: state.m2Terreno,
    setM2Terreno,
    anchoTerreno: state.anchoTerreno,
    setAnchoTerreno,
    largoTerreno: state.largoTerreno,
    setLargoTerreno,
    niveles: state.niveles,
    setNiveles,
    costoMantenimiento: state.costoMantenimiento,
    setCostoMantenimiento,
    antiguedad: state.antiguedad,
    setAntiguedad,
    amueblado: state.amueblado,
    setAmueblado,
    petFriendly: state.petFriendly,
    setPetFriendly,
    camposVisibles,

    // Amenidades
    amenidadesSeleccionadas: state.amenidadesSeleccionadas,
    toggleAmenidad,

    // Comisión Venta
    comparteComision: state.comparteComision,
    setComparteComision,
    comisionTipo: state.comisionTipo,
    setComisionTipo,
    comisionValor: state.comisionValor,
    setComisionValor,
    comisionCompartidaTipo: state.comisionCompartidaTipo,
    setComisionCompartidaTipo,
    comisionCompartidaValor: state.comisionCompartidaValor,
    setComisionCompartidaValor,
    condicionesComision: state.condicionesComision,
    setCondicionesComision,

    // Comisión Renta
    comparteComisionRenta: state.comparteComisionRenta,
    setComparteComisionRenta,
    comisionTipoRenta: state.comisionTipoRenta,
    setComisionTipoRenta,
    comisionValorRenta: state.comisionValorRenta,
    setComisionValorRenta,
    comisionCompartidaTipoRenta: state.comisionCompartidaTipoRenta,
    setComisionCompartidaTipoRenta,
    comisionCompartidaValorRenta: state.comisionCompartidaValorRenta,
    setComisionCompartidaValorRenta,
    condicionesComisionRenta: state.condicionesComisionRenta,
    setCondicionesComisionRenta,

    // Gravamen
    tieneGravamen: state.tieneGravamen,
    setTieneGravamen,
    institucionGravamen: state.institucionGravamen,
    setInstitucionGravamen,
    montosGravamen: state.montosGravamen,
    setMontosGravamen,

    // Financiamiento
    aceptaFinanciamiento: state.aceptaFinanciamiento,
    setAceptaFinanciamiento,
    tiposFinanciamientoSeleccionados: state.tiposFinanciamientoSeleccionados,
    toggleFinanciamiento,

    // Propietario
    nombreCompletoPropietario: state.nombreCompletoPropietario,
    setNombreCompletoPropietario,
    emailPropietario: state.emailPropietario,
    setEmailPropietario,
    telefonoPropietario: state.telefonoPropietario,
    setTelefonoPropietario,

    // EasyBroker
    sinComision: state.sinComision,

    // Campos especializados — Agrícola
    tiposAgua: state.tiposAgua,
    toggleTipoAgua,
    concesionAgua: state.concesionAgua,
    setConcesionAgua,
    usoTerreno: state.usoTerreno,
    toggleUsoTerreno,
    tipoRiego: state.tipoRiego,
    toggleTipoRiego,
    infraElectricidad: state.infraElectricidad,
    setInfraElectricidad,
    infraCaminoAcceso: state.infraCaminoAcceso,
    setInfraCaminoAcceso,
    infraCercado: state.infraCercado,
    setInfraCercado,
    accesoCarretera: state.accesoCarretera,
    setAccesoCarretera,
    accesoCamiones: state.accesoCamiones,
    setAccesoCamiones,

    // Campos especializados — Comercial
    tipoUbicacionComercial: state.tipoUbicacionComercial,
    setTipoUbicacionComercial,
    frenteMetros: state.frenteMetros,
    setFrenteMetros,
    nivelPiso: state.nivelPiso,
    setNivelPiso,
    sobreAvenidaPrincipal: state.sobreAvenidaPrincipal,
    setSobreAvenidaPrincipal,
    enEsquina: state.enEsquina,
    setEnEsquina,
    altaVisibilidad: state.altaVisibilidad,
    setAltaVisibilidad,
    altoFlujoVehicular: state.altoFlujoVehicular,
    setAltoFlujoVehicular,

    // Campos especializados — Industrial
    ubicacionIndustrial: state.ubicacionIndustrial,
    setUbicacionIndustrial,
    alturaLibreM: state.alturaLibreM,
    setAlturaLibreM,
    tipoEnergiaKva: state.tipoEnergiaKva,
    toggleTipoEnergiaKva,
    areaOficinas: state.areaOficinas,
    setAreaOficinas,
    patioManiobras: state.patioManiobras,
    setPatioManiobras,

    // Errors
    errors: state.errors,
    setErrors,
    clearError,

    // Validation
    validate,
    getValidationErrors,

    // Cambios sin guardar
    isDirty,

    // Helpers
    handleCurrencyChange,
  };
}
