import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";
import { logger } from "@/utils/logger";const log = logger.scoped("supabase");

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  log.error("Supabase config missing! Check your .env file.");
} else {
  log.debug("Supabase config loaded:", {
    urlLength: supabaseUrl.length,
    keyLength: supabaseAnonKey.length,
    urlStart: supabaseUrl.substring(0, 8) + "...",
  });
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
  global: {
    headers: {
      'x-my-custom-header': 'ilyrox-app',
    },
  },
});
